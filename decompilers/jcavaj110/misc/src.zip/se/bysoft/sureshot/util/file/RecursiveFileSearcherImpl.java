/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.util.file;

import java.io.File;
import java.util.*;


/**
 * Search for files in the filesystem.
 *
 * @author  Roger Karlsson
 * @since   September 11, 2002
 */
public class RecursiveFileSearcherImpl implements RecursiveFileSearcher
{
    /**
     *
     */
    public RecursiveFileSearcherImpl() 
    {
    }
    
    /**
     * See the interface.
     */
    public void scan(final String[] paths, final ListIterator dest) 
    {
        for (int i = 0; i < paths.length; ++i)
        {
            _scan(new File(paths[0]), dest);
        }
    }
    
    /**
     *
     */
    private void _scan(final File dir, final ListIterator dest) 
    {
        final String[] entries = dir.list();
        if (entries == null || entries.length < 1) 
        {
            return;
        }
        for (int i = 0; i < entries.length; i++) 
        {
            final File entry = new File(dir, entries[i]);
            if (entry.isDirectory()) 
            {
                //Scan the directory by a recursive call.
                _scan(entry, dest);
            } 
            else 
            {
                //A file was found, add it to the iterator.
                dest.add(entry.getAbsolutePath());
            }
        }
    }   
}
