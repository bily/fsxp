/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.util.config;

import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/**
 * Implementation of the ValueStorage interface. Stores the
 * mapping on disk.
 *
 * @author Roger Karlsson
 * @since  April 10, 2002
 */
public class ValueStorageImpl implements ValueStorage
{
    /**
     * Constructor.
     *
     * @param directory  The directory where the mappings are stored.
     */
    public ValueStorageImpl(final String directory)
        throws ValueStorageException
    {
        _directory = directory;
        try
        {
            if (directory == null)
            {
                final String m = 
                    "Could not open the directory with values since " +
                    "the directory parameter is null";
                throw new ValueStorageException(m);
            }

            //Read all keys and values.
            final File dir = new File(directory);
            
            //Create a directory if it does not exist.
            if (!dir.exists())
            {
                final boolean created = dir.mkdirs();
                if (!created)
                {
                    final String m = "Could not create the directory: " + 
                        dir;
                    throw new ValueStorageException(m);
                }
                return;
            }
            
            //Read all values in the directory. Add a mapping for each file.
            final File[] files = dir.listFiles();
            for (int i = 0; i < files.length; ++i)
            {
                final byte[] b = new byte[(int)files[i].length()];
                final FileInputStream fis = new FileInputStream(files[i]);
                fis.read(b);
                fis.close();
                final String filename = files[i].getName();
                final String key = filename.substring(0, filename.length() - 4);
                final String value = new String(b);
                _p.put(key , value);
            }
        }
        catch (IOException e)
        {
            final String m = "Error loading file. The file was not found.\n" +
                "Directory: " + _directory +
                "Reason: " + e;
            throw new ValueStorageException(m);
        }
    }
    
    /**
     * Create a value store at the default location.
     */
    public ValueStorageImpl() throws ValueStorageException
    {
        this(System.getProperty("user.home") + File.separatorChar + 
            ".sureshot" + File.separatorChar + "valuestorage");
    }
    
    /**
     * See the interface.
     */
    public void set(final String key, final String value)
        throws ValueStorageException
    {
        final String name = _directory + File.separatorChar + key + ".txt";
        try
        {
            final File file = new File(name);
            final FileOutputStream fos = new FileOutputStream(file);
            fos.write(value.getBytes());
            fos.close();
        }
        catch (IOException e)
        {
            final String m = "Error saving value.\n" +
                "filename: " + name + "\n" +
                "value: " + value + "\n" +
                "Reason: " + e;
            throw new ValueStorageException(m);
        }
        _p.put(key, value);
    }
    
    /**
     * See the interface.
     */
    public String get(final String key, final String defaultValue)
    {
        final String value = (String)_p.get(key);
        return value == null ? defaultValue : value;
    }
    
    private final Properties _p = new Properties();
    private final String _directory;
}
