/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.util.image;

import java.awt.Image;

/**
 * Interface used when loading images.
 *
 * @author Roger Karlsson
 * @since  February 22, 2002
 */
public interface ImageLoader 
{
    /**
     * Loads a single image.
     *
     * @param imageName  The name of the image. C:\image.gif for example.
     *
     * @exception ImageLoaderException  If there is some problems to load the
     *                                  image.
     *
     * @return The image.
     */
    Image load(String imageName) throws ImageLoaderException;
    
    /**
     * Loads an array of images.
     *
     * @param imageNames  Array of image names to load.
     *
     * @exception ImageLoaderException  If there is some problems to load the
     *                                  images.
     *
     * @return The array of loaded images.
     */
    Image[] load(String[] imageNames) throws ImageLoaderException;
}
