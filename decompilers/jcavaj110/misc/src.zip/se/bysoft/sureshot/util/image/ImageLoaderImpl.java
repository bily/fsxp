/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.util.image;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.JPanel;

import se.bysoft.sureshot.debug.Assertion;

/**
 * Implementation of the ImageLoader interface.
 *
 * @author Roger Karlsson
 * @since  February 22, 2002
 */
public class ImageLoaderImpl implements ImageLoader
{
    /**
     * See the interface.
     */
    public Image load(final String imageName) throws ImageLoaderException
    {
        //Create a media tracker with a dummy JPanel.
        final MediaTracker tracker = new MediaTracker(new JPanel());
        
        //Try to set up a URL pointing into the jar file. May return null.
        final URL url = getClass().getResource(imageName);
        
        //Load the actual image.
        final Image image = url == null ? 
            Toolkit.getDefaultToolkit().getImage(imageName) : 
            Toolkit.getDefaultToolkit().getImage(url);
        
        Assertion.assertion(image != null);

        //Make sure that the image is loaded 100% before we
        //start using it.
        tracker.addImage(image, 0);

        try 
        { 
            // Wait until the image is done loading
            tracker.waitForID(0); 
        }      
        catch (InterruptedException e) 
        {
            //Can never happen.
            Assertion.assertion(false);
        }
        
        //Check for errors during loading.
        if (tracker.isErrorAny())
        {
            final String s = "Could not load the image. " +
                "Image name: " + imageName + "\n" +
                "Using url:" + url + "\n";
            throw new ImageLoaderException(s);
        }
        
        return image;
    }
    
    /**
     * See the interface.
     */
    public Image[] load(final String[] imageNames) throws ImageLoaderException 
    {
        //Load the images
        final Image[] images = new Image[imageNames.length];
        for (int i = 0; i < imageNames.length; ++i)
        {
            images[i] = load(imageNames[i]);
        }
        return images;
    }
    
}
