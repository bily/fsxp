/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.products.jcavaj.gui;

import java.awt.*;
import java.beans.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import se.bysoft.sureshot.debug.Assertion;

/**
 * The internal frame.
 *
 * @author Roger Karlsson
 * @since  September 11, 2002
 */
public class CodeInternalFrame extends JInternalFrame 
{
    //Counts the number of frames created so far.
    private static int _frameCounter = 0;
    
    //The offset when opening new windows.
    private static final int xOffset = 30, yOffset = 30;
    
    //All existing frames are stored in this map, added in the construtor
    //and deleted when the internal frame is closed.
    private static final Map _docNameToInternalFrame = new HashMap();
    
    /**
     * Creates an internal frame.
     *
     * @param docName      The name of the document.
     * @param codeOrError  Source code or an error message.
     */
    public CodeInternalFrame(final String docName, 
                             final String codeOrError)
    {
        super(docName, 
              true, //resizable
              true, //closable
              true, //maximizable
              true);//iconifiable

        _docName = docName;
        _codeOrError = codeOrError;
    
        //Set the window size. This size is used when the window is
        //normalized.
        setSize(400,400);

        //Set the window's location.
        ++_frameCounter;
        setLocation(xOffset * (_frameCounter % 5), yOffset * (_frameCounter % 5));

        _editPane = new JEditorPane("text/plain", codeOrError);
        _editPane.setEditable(false);

        //Create the scroll pane and add the tree to it. 
        _scrollPane = new JScrollPane(_editPane);
        
        //The two calls below does not work. See MainFrame._fixScrollPane.
        _scrollPane.getVerticalScrollBar().getModel().setValue(0);
        _scrollPane.getVerticalScrollBar().setValue(0);

        //Add the internal frame in the map.
        _docNameToInternalFrame.put(_docName, this);
        
        //Set a listener, called when the internal frame closes.
        addInternalFrameListener(new InternalFrameAdapter(){
            public void internalFrameClosed(final InternalFrameEvent e)
            {
                Assertion.assertion(_docNameToInternalFrame.
                    containsKey(_docName));
                _docNameToInternalFrame.remove(_docName);
            }
        });
        
        setContentPane(_scrollPane);        
    }
    
    /**
     * @param docName  The name of the internal frame.
     * @return The frame with the specified name.
     */
    public static CodeInternalFrame getInternalFrame(final String docName)
    {
        return (CodeInternalFrame)_docNameToInternalFrame.get(docName);
    }
    
    /**
     * Adjust the scroll pane.
     */
    public void adjustScrollPane()
    {
        _scrollPane.getVerticalScrollBar().setValue(0);
        //_scrollPane.validate();
    }
    
    /**
     * Sets the source code in the editor pane.
     *
     * @param code  The source code.
     */
    public void updateCodeOrError(final String codeOrError)
    {
        if (!codeOrError.equals(_codeOrError))
        {
            _codeOrError = codeOrError;
            _editPane.setText(_codeOrError);
        }
    }
    
    private final String _docName;
    private final JEditorPane _editPane;
    
    private final JScrollPane _scrollPane;
    
    private String _codeOrError;
}
