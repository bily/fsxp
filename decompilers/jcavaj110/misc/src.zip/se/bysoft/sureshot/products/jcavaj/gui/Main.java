/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.products.jcavaj.gui;

import java.util.*;
import javax.swing.*;

import se.bysoft.sureshot.gui.util.GuiHelper;
import se.bysoft.sureshot.debug.Assertion;
import se.bysoft.sureshot.util.reporter.*;
import se.bysoft.sureshot.util.*;

/**
 * Start up class for JCavaj.
 *
 * @author Roger Karlsson
 * @since  September 10, 2002
 */
public class Main 
{
    /**
     *
     */
    public static void main(final String[] args)
    {         
        final MessageBoxReporter reporter
            = new MessageBoxReporter(null, "JCavaj");
        
        try
        {
            final boolean debug = Arrays.asList(args).contains("-debug");
        
            final MainFrame mf = new MainFrame(debug);
            GuiHelper.center(mf);
            mf.setVisible(true);
        }
        catch (Exception e)
        {
            final String m = "Error during startup. " + e.getMessage() + "\n" +
                ExceptionHelper.getStackTrace(e);
            reporter.reportError(m);
            System.err.println(m);
        }
    }
}
