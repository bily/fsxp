/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.products.jcavaj.gui;

import com.l2fprod.gui.plaf.skin.Skin;
import com.l2fprod.gui.plaf.skin.CompoundSkin;
import com.l2fprod.gui.plaf.skin.SkinLookAndFeel;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

import se.bysoft.sureshot.debug.Assertion;
import se.bysoft.sureshot.gui.browser.*;
import se.bysoft.sureshot.gui.splashscreen.*;
import se.bysoft.sureshot.gui.util.*;
import se.bysoft.sureshot.products.jcavaj.engine.*;
import se.bysoft.sureshot.util.*;
import se.bysoft.sureshot.util.config.*;
import se.bysoft.sureshot.util.file.*;
import se.bysoft.sureshot.util.image.*;
import se.bysoft.sureshot.util.reporter.*;
import se.bysoft.sureshot.util.string.*;

/**
 * The main frame class of JCavaj. Does all the major work.
 *
 * @author Roger Karlsson
 * @since  September 10, 2002
 */
public class MainFrame extends JFrame
{
    /**
     * Enumeration for the look and feel.
     */
    private static class LookAndFeel
    {
        private LookAndFeel() {};
        private static LookAndFeel JAVA  = new LookAndFeel();
        private static LookAndFeel XP    = new LookAndFeel();
        private static LookAndFeel MOTIF = new LookAndFeel();
    }
    
    /**
     * Creates the main frame.
     *
     * @param debug  Should images be loaded from local disk?
     */
    public MainFrame(final boolean debug) 
        throws ImageLoaderException, ZipException, IOException, Exception
    {           
        _debug = debug;
        
        //Create a splash screen.
        final ImageLoader imageLoader = new ImageLoaderImpl();
        final SplashScreenImpl splash = 
            new SplashScreenImpl(
                this, 
                _debug ? 
                    "E:\\products\\jcavaj\\graphics\\jcavaj\\splash.gif" : 
                    "/graphics/jcavaj/splash.gif", 
                imageLoader);
        splash.display();
        
        _setLookAndFeel(LookAndFeel.XP);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Load class path
        final String dir = 
            System.getProperty(_userHomeKey) + File.separator + ".jcavaj";
        _valueStorage = new ValueStorageImpl(dir);
        final String classPath = 
            _valueStorage.get(_valueStorageKey, System.getProperty(_classPathKey));
        _setClassPath(classPath);
        
        final MessageBoxReporter reporter = 
            new MessageBoxReporter(this, "JCavaj");
        _errorReporter = reporter;
        _infoReporter = reporter;
        
        _desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        //Create the nodes.
        _topTreeNode = new DefaultMutableTreeNode("Classes load from classpath");
        createNodes(_topTreeNode);
        
        //Create a tree that allows one selection at a time.
        _treeModel = new DefaultTreeModel(_topTreeNode);
        _tree = new JTree(_treeModel);
        _tree.putClientProperty("JTree.lineStyle", "Angled");
        _tree.getSelectionModel().setSelectionMode
                (TreeSelectionModel.SINGLE_TREE_SELECTION);
        
        final DefaultTreeCellRenderer renderer = 
            new DefaultTreeCellRenderer();
        
        setTitle("JCavaj");
        
        setIconImage(imageLoader.load(_debug ? 
        "E:\\products\\jcavaj\\graphics\\jcavaj\\class_big.gif" : 
            "/graphics/jcavaj/class_big.gif"));
        
        final ImageIcon leafIcon = 
            new ImageIcon(imageLoader.load(_debug ? 
            "E:\\products\\jcavaj\\graphics\\jcavaj\\class_small.gif" : 
                "/graphics/jcavaj/class_small.gif"));
        renderer.setLeafIcon(leafIcon);
        _tree.setCellRenderer(renderer);

        //Listen for when the selection changes.
        _tree.addTreeSelectionListener(new TreeSelectionListener() {
            public void valueChanged(TreeSelectionEvent event) {
                
                final String errorMessage =
                    "Please check the following:\n" +
                    "1. Are the necessary classes available in the class\n" +
                    "   path? For example,\n" +
                    "   Let's say you decompile class X. X uses class Y and\n" +
                    "   Y uses class Z. Both class Y and Z must be available in\n" +
                    "   the class path. You can change the class path in the\n" +
                    "   settings menu.\n" +
                    "2. Could this be a possible bug? Please contact us. You\n" +
                    "   can find more information about how to send a bug\n" +
                    "   report in the manual and faq.\n" +
                    "3. Please try our decompiler available for the Windows\n" +
                    "   platform. It uses a different decompiler engine and\n" +
                    "   might be able to decompile the class.\n" +
                    "   http://www.bysoft.se/sureshot/cavaj/index.html\n";
                    
                try
                {
                    final DefaultMutableTreeNode node = 
                        (DefaultMutableTreeNode)
                            _tree.getLastSelectedPathComponent();

                    if (node == null)
                    {
                        return;
                    }

                    final Object nodeInfo = node.getUserObject();
                    if (node.isLeaf() && nodeInfo instanceof ClassInfo) 
                    {
                        final ClassInfo classInfo = (ClassInfo)nodeInfo;
                        final ByteArrayOutputStream baos = 
                            new ByteArrayOutputStream();
                        final Writer writer = new PrintWriter(baos);
                        _decompiler.decompile(writer, classInfo.className);
                        
                        final StringBuffer code = 
                            new StringBuffer(baos.toString());
                        
                        StringHelper.replaceFirst(
                            code, "Decompiled by JODE", 
                            "Decompiled by JCavaj");
                        StringHelper.replaceFirst(
                            code, "http://jode.sourceforge.net/", 
                            "http://www.bysoft.se/sureshot/jcavaj/");
                      
                        //View the data in the edit pane.
                        final CodeInternalFrame f = 
                            _createFrame(classInfo.className, code.toString());
                    }
                }
                catch (final IOException e)
                {
                    final String m = 
                        "Error decompiling class.\n" +
                        errorMessage + "\n" +
                        e + "\n" +
                        ExceptionHelper.getStackTrace(e);
                    _createFrame(_errorMessageDocName, m);
                }
                catch (final Throwable e)
                {
                    final String m = 
                        "Error decompiling class.\n" +
                        errorMessage + "\n" +
                        e + "\n" +
                        ExceptionHelper.getStackTrace(e);
                    _createFrame(_errorMessageDocName, m);
                }
            }
        });
        
        setJMenuBar(createMenuBar());

        //Create the scroll pane and add the tree to it. 
        final JScrollPane treeView = new JScrollPane(_tree);
        
        final JSplitPane splitPane = 
            new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                           treeView, _desktop);
        
        splitPane.setPreferredSize(new Dimension(800, 600));
        getContentPane().add(splitPane);
        pack();
    }
    
    /**
     * By some reason, the scroll pane holding the editor pane 
     * scrolls down to the bottom of the editor pane. That problem is
     * solved by adjusting the scroll bar later on using the AWT thread.
     *
     * It does not work to adjust it right away, why?
     *
     * @param frame  The internal frame that should adjust its scrollbar.
     */
    private void _fixScrollPane(final CodeInternalFrame frame)
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                frame.adjustScrollPane();
            }
        });
    }
    
    /**
     * Creates the complete menu bar.
     *
     * @return The menu bar.
     */
    protected JMenuBar createMenuBar() 
    {
        final JMenuBar menuBar = new JMenuBar();

        //Create the FILE menu.
        {
            final JMenu fileMenu = new JMenu("File");
            fileMenu.setMnemonic(KeyEvent.VK_F);
            fileMenu.add(new ExitAction());
            menuBar.add(fileMenu);
        }
        
        //Create the Settings menu.
        {
            final JMenu settingsMenu = new JMenu("Settings");
            settingsMenu.setMnemonic(KeyEvent.VK_S);
            
            final JMenuItem classPathItem = new JMenuItem("Set class path");
            classPathItem.setMnemonic(KeyEvent.VK_S);
            
            classPathItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(final ActionEvent event) 
                {
                    try
                    {
                        final String defaultText = 
                            System.getProperty(_classPathKey);
                        final String toolTip= 
                            "Add or remove entries from the class path. Use " +
                            File.pathSeparator + " as a separator between " +
                            "the paths.";
                        final String title = "Set the class path.";
                        final String message = toolTip;
                        final int textFieldSize = 60;
                        final TextFieldDialog tfd = 
                            new TextFieldDialog(MainFrame.this,
                                                defaultText,
                                                toolTip,
                                                title,
                                                message,
                                                textFieldSize);
                        tfd.setVisible(true);
                        final TextFieldDialog.Action ret = 
                            tfd.getReturnAction();
                        if (ret == TextFieldDialog.Action.OK)
                        {
                            //Update the class path.
                            final String newClassPath = tfd.getTextFieldString();
                            _setClassPath(newClassPath);

                            //Update the tree view.
                            createNodes(_topTreeNode);
                            _treeModel.reload();
                            
                            //Save class path to disk.
                            _valueStorage.set(_valueStorageKey, newClassPath);
                        }
                    }
                    catch (ZipException e)
                    {
                        final String m = 
                            "An error occured while updating the class " + 
                            "path. Problems with Zip file. " + e;
                        _errorReporter.reportError(m);
                    }
                    catch (IOException e)
                    {
                        final String m = 
                            "An error occured while updating the class " + 
                            "path. IOException: " + e;
                        _errorReporter.reportError(m);
                    }
                }
            });
            settingsMenu.add(classPathItem);
            

            /*settingsMenu.addSeparator();
            
            //Add radio buttons for the look and feel.
            //TBD, reduce code!
            final ButtonGroup group = new ButtonGroup();
            {
                final JRadioButtonMenuItem rbMenuItem = 
                    new JRadioButtonMenuItem("XP look and feel.");
                rbMenuItem.addActionListener(new ActionListener()
                {
                    public void actionPerformed(final ActionEvent ev)
                    {
                        try
                        {
                            _setLookAndFeel(LookAndFeel.XP);
                        }
                        catch (final Exception e)
                        {
                            final String m = 
                                "Error setting XP look and feel. " + e;
                            _errorReporter.reportError(m);
                        }
                    }
                });
                rbMenuItem.setSelected(true);
                rbMenuItem.setMnemonic(KeyEvent.VK_X);
                group.add(rbMenuItem);
                settingsMenu.add(rbMenuItem);
            }

            {
                final JRadioButtonMenuItem rbMenuItem = 
                    new JRadioButtonMenuItem("Java look and feel.");
                rbMenuItem.addActionListener(new ActionListener()
                {
                    public void actionPerformed(final ActionEvent ev)
                    {
                        try
                        {
                            _setLookAndFeel(LookAndFeel.JAVA);
                        }
                        catch (final Exception e)
                        {
                            final String m = 
                                "Error setting JAVA look and feel. " + e;
                            _errorReporter.reportError(m);
                        }
                    }
                });

                rbMenuItem.setMnemonic(KeyEvent.VK_J);
                group.add(rbMenuItem);
                settingsMenu.add(rbMenuItem);
            }
            
            {
                final JRadioButtonMenuItem rbMenuItem = 
                    new JRadioButtonMenuItem("Motif look and feel.");
                rbMenuItem.addActionListener(new ActionListener()
                {
                    public void actionPerformed(final ActionEvent ev)
                    {
                        try
                        {
                            _setLookAndFeel(LookAndFeel.MOTIF);
                        }
                        catch (final Exception e)
                        {
                            final String m = 
                                "Error setting MOTIF look and feel. " + e;
                            _errorReporter.reportError(m);
                        }
                    }
                });

                rbMenuItem.setMnemonic(KeyEvent.VK_J);
                group.add(rbMenuItem);
                settingsMenu.add(rbMenuItem);
            }*/
            
            menuBar.add(settingsMenu);
        }
        
        //Create the HELP menu.
        {
            final JMenu helpMenu = new JMenu("Help");
            helpMenu.setMnemonic(KeyEvent.VK_H);
            
            //Add the SURESHOT home page item.
            final OpenDefaultBrowserAction sureshotHomepage = 
                new OpenDefaultBrowserAction(
                    "Sureshot's homepage",
                    "http://www.bysoft.se/sureshot/",
                    !_debug);
            helpMenu.add(sureshotHomepage);
            

            //Add the JCAVAJ home page item.
            final OpenDefaultBrowserAction jcavajHomepage = 
                new OpenDefaultBrowserAction(
                    "JCavaj's homepage",
                    "http://www.bysoft.se/sureshot/jcavaj/",
                    !_debug);
            helpMenu.add(jcavajHomepage);
            
            //Add the JiveLint home page item.
            final OpenDefaultBrowserAction jivelintHomepage = 
                new OpenDefaultBrowserAction(
                    "Improve your source code",
                    "http://www.bysoft.se/sureshot/javalint/",
                    !_debug);
            helpMenu.add(jivelintHomepage);
            
            helpMenu.addSeparator();
            
            //Add the ABOUT item.
            helpMenu.add(new AboutAction(new Runnable()
            {
                public void run()
                {
                    final String m =
                        "\n" +
                        "JCavaj version 1.00, Copyright (C) 2002 Sureshot\n" +
                        "\n" +
                        "JCavaj comes with ABSOLUTELY NO WARRANTY;\n" +
                        "This is free software, and you are welcome\n" +
                        "to redistribute it under certain conditions;\n" +
                        "See the files 'COPYING.txt' and 'SKINLF.txt'\n" +
                        "for details.\n" +
                        "\n" +
                        "Please visit JCavaj's home page:\n" +
                        "http://www.bysoft.se/sureshot/jcavaj/\n" +
                        "\n" +
                        "JCavaj uses Jode as the decompiling engine:\n" +
                        "http://jode.sourceforge.net/\n" +
                        "\n" +
                        "JCavaj uses SkinLF developed by L2FProd.com:\n" +
                        "http://www.L2FProd.com/\n" +
                        "\n";
                    _infoReporter.reportInfo(m);
                }
            }));
            menuBar.add(helpMenu);
        }

        return menuBar;
    }
    
    /**
     * Create the tree and add it to the top node. The method uses the
     * classpath system property to search for classes.
     *
     * @param topNode  The top node of the tree view.
     */
    private void createNodes(final DefaultMutableTreeNode topNode)
        throws ZipException, IOException
    {
        Assertion.assertion(topNode != null);
              
        topNode.removeAllChildren();

        final String allClassPaths = System.getProperty(_classPathKey);
        final ArrayList allFilenames = new ArrayList();
        final ArrayList allClassNames = new ArrayList();
        final RecursiveFileSearcher rfs = new RecursiveFileSearcherImpl();
        final String dotClass = ".class";
        final StringTokenizer strtok = 
            new StringTokenizer(allClassPaths, File.pathSeparator);
        while (strtok.hasMoreTokens())
        {
            final File dirOrFile = new File(strtok.nextToken());
            if (dirOrFile.isDirectory())
            {
                //Scan the directory for files.
                final String[] path = {dirOrFile.getAbsolutePath()};
                rfs.scan(path, allFilenames.listIterator());
                
                //remove all files not starting with .class
                for (final Iterator i = allFilenames.listIterator();
                     i.hasNext();)
                {
                    //Get the filename.
                    final String current = (String)i.next();
                    if (current.endsWith(dotClass))
                    {
                        //Get the relative path.
                        final String relativePath = 
                            current.substring(path[0].length() + 1, 
                                              current.length());
                        
                        //From the relative path, get the class name.
                        //Do this by removing .class and replacing
                        // '/' and '\' with '.'.
                        final String className = 
                            relativePath.substring(0, relativePath.length() -
                                dotClass.length()).replace('/', '.').
                                replace('\\', '.');
                        allClassNames.add(className);
                    }
                }
            }
            else
            {
                //Check if .jar or .zip file.
                if (dirOrFile.getName().endsWith(".zip") || 
                    dirOrFile.getName().endsWith(".jar"))
                {
                    if (!dirOrFile.exists())
                    {
                        final String m = "The file '" + dirOrFile +
                            "' does not exist. Please correct the class path.\n" +
                            "The current class path: " + allClassPaths;
                        _errorReporter.reportError(m);
                        continue;
                    }
                    
                    //Create a zip file and get all names ending with
                    // .class.
                    final ZipFile zipFile = new ZipFile(dirOrFile);
                    for (final Enumeration e = zipFile.entries(); 
                         e.hasMoreElements(); )
                    {
                        final String entry = 
                            ((ZipEntry) e.nextElement()).getName();
                        
                        if (entry.endsWith(dotClass))
                        {
                            final String className = 
                                entry.substring(0, entry.length() -
                                    dotClass.length()).
                                        replace('\\', '.').
                                        replace('/', '.');
                            allClassNames.add(className);
                        }
                    }
                }
            }
        }
        
        //Create the actual tree.
        final String nodeKey = ".node.";
        final HashMap topMap = new HashMap();
        topMap.put(nodeKey, topNode);
        for (final Iterator i = allClassNames.iterator(); i.hasNext();)
        {
            final String packageAndClassName = (String)i.next();
            final StringTokenizer st = 
                new StringTokenizer(packageAndClassName, ".");
            
            HashMap map = topMap;
            while (st.hasMoreTokens())
            {
                final String current = st.nextToken();
                if (st.hasMoreTokens())
                {
                    //current is a package component, get the
                    //hashmap corresponding to the package.
                    final HashMap newMap = (HashMap) map.get(current);
                    if (newMap == null)
                    {
                        //Create a new node in the tree and in the map.
                        final DefaultMutableTreeNode newPackageNode = 
                            new DefaultMutableTreeNode(current);
                        final HashMap tmp = new HashMap();
                        tmp.put(nodeKey, newPackageNode);
                        map.put(current, tmp);
                        final DefaultMutableTreeNode parentNode = 
                            (DefaultMutableTreeNode)map.get(nodeKey);
                        parentNode.add(newPackageNode);
                        map = tmp;
                    }
                    else
                    {
                        map = newMap;
                    }
                }
                else
                {
                    //Current is a class name. Create a leaf node and
                    //add it in parent node.
                    final DefaultMutableTreeNode node = 
                        (DefaultMutableTreeNode) map.get(nodeKey);
                    final ClassInfo ci = 
                        new ClassInfo(current, packageAndClassName);
                    node.add(new DefaultMutableTreeNode(ci));
                }
            }   
        }
    }
    
    /**
     * Create a new internal frame.
     *
     * @param docName      The name/title of the frame.
     * @param codeOrError  The source code or the error message.
     */
    private CodeInternalFrame _createFrame(final String docName, 
                                           final String codeOrError) 
    {
        //Make a look up, does a frame with the specified name (title)
        //already exist?
        CodeInternalFrame frame = 
            CodeInternalFrame.getInternalFrame(docName);
        if (frame != null)
        {
            //The frame did already exist. Update the code/error message
            //and bring it to the front.
            frame.updateCodeOrError(codeOrError);
            frame.moveToFront();
            if (frame.isIcon())
            {
                try
                {
                    frame.setMaximum(true);
                }
                catch (java.beans.PropertyVetoException e)
                {
                    //Can never happen, or?
                    e.printStackTrace();
                    Assertion.assertion(false);
                }
            }
            
            try
            {
                //Can never happen, or?
                frame.setSelected(true);
            }
            catch (java.beans.PropertyVetoException e)
            {
                e.printStackTrace();
                Assertion.assertion(false);
            }
        }
        else
        {
            //Create a new frame and add it to the desktop.
            frame = new CodeInternalFrame(docName, codeOrError);
            _desktop.add(frame);
            frame.setVisible(true);
            frame.adjustScrollPane();

            try 
            {
                //Can never happen, or?
                frame.setSelected(true);
                frame.setMaximum(true);
            } 
            catch (java.beans.PropertyVetoException e) 
            {
                //Can never happen, or?
                e.printStackTrace();
                Assertion.assertion(false);
            }
        }
        _fixScrollPane(frame);
        return frame;
    }
    
    /**
     * Sets the class path.
     *
     * @param classPath  The class path.
     */
    private void _setClassPath(final String classPath)
    {
	_decompiler.setClassPath(classPath);
    }
    
    /**
     * Set the look and feel.
     *
     * @param newType  The new look and feel.
     */
    private void _setLookAndFeel(final LookAndFeel newType)
        throws Exception
    {
        if (newType == LookAndFeel.XP)
        {
            final Skin skin = SkinLookAndFeel.loadDefaultThemePack();
            SkinLookAndFeel.setSkin(skin);
            // ask Swing to use Skin Look And Feel
            final String s = "com.l2fprod.gui.plaf.skin.SkinLookAndFeel";
            UIManager.setLookAndFeel(s);
        }
        else if (newType == LookAndFeel.JAVA)
        {
            UIManager.setLookAndFeel(
                UIManager.getCrossPlatformLookAndFeelClassName());
        }
        else if (newType == LookAndFeel.MOTIF)
        {
            final String s = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
            UIManager.setLookAndFeel(s);
        }
        else
        {
            //Assert for early error detection.
            Assertion.assertion(false);
        }
        
        //The look and feel changed (possibly), update all components.
        SwingUtilities.updateComponentTreeUI(this);        
        this.pack();
    }
        
    /**
     * Node used in the tree view.
     */
    private class ClassInfo 
    {
        //The name that should be displayed in the tree view.
        public String viewName;
        
        //The name of the actual class, including package.
        public String className;

        /**
         * Creates a class info.
         *
         * @param viewName   Name that should be displayed in the tree view.
         * @param className  Name of the actual class, including package.
         */
        public ClassInfo(final String viewName, String className) 
        {
            this.viewName = viewName;
            this.className = className;
        }

        /**
         * The tree view calls this to get the string used for the node.
         */
        public String toString() 
        {
            return viewName;
        }
    }
    
    private final DefaultMutableTreeNode _topTreeNode;
    private final DefaultTreeModel _treeModel;
    private final ValueStorage _valueStorage;
    private final String _classPathKey = "java.class.path";
    private final String _userHomeKey = "user.home";
    private final String _valueStorageKey = "classpath";
    private final String _errorMessageDocName = "Decompiler Error";
    private final JTree _tree;
    
    private final boolean _debug;
    private final Decompiler _decompiler = new JodeDecompiler();
    private final JDesktopPane _desktop = new JDesktopPane();
    private final ErrorReporter _errorReporter;
    private final InfoReporter _infoReporter;
}
