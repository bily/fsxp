/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.gui.splashscreen;

import java.awt.Toolkit;
import java.awt.Image;
import java.awt.Dimension;
import java.awt.Graphics;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JWindow;
import javax.swing.JFrame;

import se.bysoft.sureshot.util.image.ImageLoader;
import se.bysoft.sureshot.util.image.ImageLoaderException;

/**
 * Default implementation of the SplashScreen
 *
 * @author Roger Karlsson
 * @since  February 22, 2002
 */
public class SplashScreenImpl extends JWindow implements SplashScreen
{ 
    /**
     * Creates the default splash screen.
     *
     * @param parent       The splash screen will close when this frame
     *                     becomes invisible.
     * @param imageName    The name of the image containing the splash
     *                     screen image.
     * @param imageLoader  The image loader.
     */
    public SplashScreenImpl(final JFrame parent, 
                            final String imageName,
                            final ImageLoader imageLoader)
    throws ImageLoaderException
    { 
        super(parent); 
        
        _image = imageLoader.load(imageName);

        _imageWidth  = _image.getWidth(null);
        _imageHeight = _image.getHeight(null);
        
        //Attached to the main application window. The splash is closed
        //when the main frame is set visible.
        //TBD, should we unregister the listener?  Impossible to unregister
        //an anonymous object. Could result in a memory leak?
        parent.addWindowListener(new WindowAdapter()
        {
            public void windowActivated(final WindowEvent e) { closeIt(); }
        });
    }

    /**
     * Show the Splash Screen image in the center of the screen
     */
    public void display()
    {
        final Dimension screenSize = 
            Toolkit.getDefaultToolkit().getScreenSize();

        final int x = (screenSize.width  - _imageWidth)  / 2;
        final int y = (screenSize.height - _imageHeight) / 2;

        setBounds(x, y, _imageWidth, _imageHeight);
        setVisible(true);
    }

    
    /**
     * Show the Splash Screen image at the specified coordinates.
     *
     * @param x  The x position of the splash screen.
     * @param y  The y position of the splash screen.
     */
    public void display(final int x, final int y)
    {
        setBounds(x, y, _imageWidth, _imageHeight);
        setVisible(true);
    }

    /**
     * Draws the image on the window.
     *
     * @param g   A graphics device context automatically passed to 
     *            this routine.
     */
    public void paint(final Graphics g)
    {
        g.drawImage(_image, 0, 0, _imageWidth, _imageHeight, null);
    }
    
    /**
     * Hides and disposes the splash screen.
     */
    public void closeIt()
    {
        setVisible(false);
        dispose();
    }
    
    private final Image _image; 
    private final int _imageWidth;
    private final int _imageHeight;
}

