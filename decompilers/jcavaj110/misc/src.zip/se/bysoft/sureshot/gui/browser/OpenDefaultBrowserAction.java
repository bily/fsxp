/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.gui.browser;

import java.awt.event.ActionEvent;
import java.io.IOException;
import javax.swing.AbstractAction;

/**
 * Action for opening a web browser. First the action tries to open
 * a browser for the Windows platform. If that does not work, a 
 * cross platform browser is opened.
 *
 * @author Roger Karlsson
 * @since  March 26, 2002
 */
public class OpenDefaultBrowserAction extends AbstractAction
{
    /**
     * The constructor.
     *
     * @param name             The name of the action.
     * @param homepage         The homepage of the browser.
     * @param loadFromJarFile  true if the images should be loaded from a
     *                         jar file, false if they should be loaded
     *                         directly from disk.
     */
    public OpenDefaultBrowserAction(final String name, 
                                    final String homepage, 
                                    final boolean loadFromJarFile)
    {
        super(name);
        _homepage = homepage;
        _loadFromJarFile = loadFromJarFile;
        super.putValue(AbstractAction.MNEMONIC_KEY, 
                       new Integer(name.charAt(0)));
    }

    public void actionPerformed(final ActionEvent ev) 
    {
        try
        {
            //Add other browsers here. e.g. Netscape for unix.
            final String WIN_PATH = "rundll32";
            final String WIN_FLAG = "url.dll,FileProtocolHandler";
            final String cmd = WIN_PATH + " " + WIN_FLAG + " " + _homepage;
            Runtime.getRuntime().exec(cmd);            
        }
        catch (IOException e)
        {
            //Could not open the default browser. Open the crossplatform
            //browser.
            _startMiniBrowser();
        }
    }
    
    private void _startMiniBrowser()
    {
        final String[] args = 
        {
            _homepage, 
            _loadFromJarFile  ? "loadfromjar" : "debug", 
            "dispose"
        };
        MiniBrowser.main(args);
    }
    
    private final String _homepage;
    private final boolean _loadFromJarFile;
}

