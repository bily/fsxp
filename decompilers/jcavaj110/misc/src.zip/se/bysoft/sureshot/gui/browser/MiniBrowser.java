/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.gui.browser;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.io.IOException;

import java.util.Observable;
import java.util.Observer;
import java.util.Stack;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;

import se.bysoft.sureshot.debug.Assertion;
import se.bysoft.sureshot.gui.util.GuiHelper;
import se.bysoft.sureshot.gui.util.Updatable;
import se.bysoft.sureshot.gui.util.UpdateCaller;
import se.bysoft.sureshot.util.image.ImageLoaderException;
import se.bysoft.sureshot.util.image.ImageLoaderImpl;

/**
 * Implements a simple web browser. The browser uses the JEditorPane
 * to display the html page.
 * 
 * There browser is build using the MVC pattern.
 *
 * @author Roger Karlsson
 * @since  March 23, 2002
 */
public class MiniBrowser 
    extends JPanel
    implements Observer, Updatable
{
    /**
     * Modifies the model and the html pane
     * when loading a url.
     */
    private class PageLoader extends Thread implements Runnable
    {
        /**
         * Constructor.
         *
         * @param url    The url that should be loaded.
         * @param model  The browser's model.
         * @param frame  The frame that owns the error dialog if there is a
         *               problem loading the url.
         */
        public PageLoader(final String url, 
                          final BrowserModel model,
                          final JFrame frame)
        {
            _url = url;
            _model = model;
            _frame = frame;
        }
        
        public void run()
        {
            //Load the url and modify the loading state. When the page
            //is successfully loaded the state is changed with a 
            //PropertyChangeListener. (set in the MiniBrowser's constructor.)
            try
            {       
                _model.newPageLoading();
                _htmlPane.setPage(_url);
            }
            catch (IOException e)
            {
                JOptionPane.showMessageDialog(_frame, e, "Error",
                                              JOptionPane.ERROR_MESSAGE);
                _model.pageLoadFinished();
            }
        }
        
        private final String _url;
        private final BrowserModel _model;
        private final JFrame _frame;
    }
    
    /**
     * Handles clicks in the html pane.
     */
    private class Hyperactive implements HyperlinkListener 
    {
        public void hyperlinkUpdate(final HyperlinkEvent e) 
        {
            if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
            {
                final JEditorPane pane = (JEditorPane) e.getSource();
                if (e instanceof HTMLFrameHyperlinkEvent) 
                {
                    //Link clicked in a frame.
                    final HTMLFrameHyperlinkEvent evt = 
                        (HTMLFrameHyperlinkEvent)e;
                    final HTMLDocument doc = (HTMLDocument)pane.getDocument();
                    doc.processHTMLFrameHyperlinkEvent(evt);
                } 
                else 
                {
                    //Click in ordinary page.
                     _model.gotoPage(e.getURL().toString());
                }
            }
        }
    }

    //indicies for the navigations button images.
    public static int BACK_IMAGE_INDEX           = 0;
    public static int BACK_OVER_IMAGE_INDEX      = 1;
    public static int BACK_PRESSED_IMAGE_INDEX   = 2;
    public static int HOME_IMAGE_INDEX           = 3;
    public static int HOME_OVER_IMAGE_INDEX      = 4;
    public static int HOME_PRESSED_IMAGE_INDEX   = 5;
    public static int GLOBE_STATIC_IMAGE_INDEX   = 6;
    public static int GLOBE_ANIMATED_IMAGE_INDEX = 7;
    public static int ICON_IMAGE_INDEX           = 8;
    public static int MAX_IMAGE_INDEX            = 9;
    
    /**
     * The MiniBrowser's constructor.
     *
     * @param homePage    The browser's home page. The browser loads this page 
     *                    when the Home button is pressed.
     * @param imageNames  A string of names to the browser's images. The images
     *                    are loaded from disk or from the jar-files in the 
     *                    classpath.
     * @param frame       The frame where the mini browser is added. The mini
     *                    browser will change the title when a new page
     *                    is displayed. Notice that the constructor does not
     *                    add the browser to the frame. This should be done
     *                    by the caller.
     * @param title       The title of the browser. This title will be set
     *                    in the frame.
     */
    public MiniBrowser(final String homePage, 
                       final String[] imageNames,
                       final JFrame frame,
                       final String title)
        throws ImageLoaderException
    {
        _frame = frame;
        _title = title;
        _frame.setTitle(_title);
        
        _model = new BrowserModel(homePage);
        _model.addObserver(this);
                 
        final Image[] images = new ImageLoaderImpl().load(imageNames);
        _frame.setIconImage(images[ICON_IMAGE_INDEX]);
                 
        setLayout(new BorderLayout());
        
        final ImageIcon animatedGlobeIcon = 
            new ImageIcon(images[GLOBE_ANIMATED_IMAGE_INDEX]);
        final ImageIcon staticGlobeIcon = 
            new ImageIcon(images[GLOBE_STATIC_IMAGE_INDEX]);
        
        final ImageIcon backIcon = 
            new ImageIcon(images[BACK_IMAGE_INDEX]);
        final ImageIcon backOverIcon = 
            new ImageIcon(images[BACK_OVER_IMAGE_INDEX]);
        final ImageIcon backPressedIcon = 
            new ImageIcon(images[BACK_PRESSED_IMAGE_INDEX]);
        
        final ImageIcon homeIcon = 
            new ImageIcon(images[HOME_IMAGE_INDEX]);
        final ImageIcon homeOverIcon = 
            new ImageIcon(images[HOME_OVER_IMAGE_INDEX]);
        final ImageIcon homePressedIcon = 
            new ImageIcon(images[HOME_PRESSED_IMAGE_INDEX]);
        
        _homeButton.setToolTipText("<html>Home</html>");
        
        _backButton.setIcon(backIcon);
        _backButton.setRolloverIcon(backOverIcon);
        _backButton.setPressedIcon(backPressedIcon);
        
        _homeButton.setIcon(homeIcon);
        _homeButton.setRolloverIcon(homeOverIcon);
        _homeButton.setPressedIcon(homePressedIcon);
        
        _backButton.setOpaque(false);
        _homeButton.setOpaque(false);
        
        _backButton.setBorder(null);
        _homeButton.setBorder(null);

        final JPanel navigationPanel = new JPanel();
        navigationPanel.setBackground(Color.white);
        navigationPanel.setLayout(new BoxLayout(navigationPanel, 
                                                BoxLayout.X_AXIS));
        navigationPanel.add(_backButton);
        navigationPanel.add(_homeButton);

        final JPanel htmlPanel = new JPanel();        
        htmlPanel.setLayout(new BorderLayout());
        
        _htmlPane.setBorder(null);
        _htmlPane.setEditable(false);
        _htmlPane.addHyperlinkListener(new Hyperactive());
        
        final JScrollPane htmlScrollPane = new JScrollPane(_htmlPane);
        htmlScrollPane.setPreferredSize(new Dimension(600,600));
        htmlScrollPane.setHorizontalScrollBarPolicy(
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        htmlScrollPane.setVerticalScrollBarPolicy(
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        htmlPanel.add(htmlScrollPane, BorderLayout.CENTER);

        add(htmlPanel, BorderLayout.CENTER);

        final JPanel addressPanel = new JPanel();
        addressPanel.setBackground(Color.white);
        addressPanel.add(new JLabel("Address: "));
        addressPanel.add(_address);

        final JPanel addressAndNavigationPanel = new JPanel();
        addressAndNavigationPanel.setBackground(Color.white);
        addressAndNavigationPanel.setLayout(
            new BoxLayout(addressAndNavigationPanel, BoxLayout.Y_AXIS));
        navigationPanel.setAlignmentX(LEFT_ALIGNMENT);
        addressPanel.setAlignmentX(LEFT_ALIGNMENT);
        addressAndNavigationPanel.add(navigationPanel);
        addressAndNavigationPanel.add(addressPanel);
        
        _animatedGlobeLabel = new JLabel(animatedGlobeIcon);
        _staticGlobeLabel = new JLabel(staticGlobeIcon);
        _animatedGlobeLabel.setOpaque(false);
        _staticGlobeLabel.setOpaque(false);
        
        final JPanel globePanel = new JPanel();
        globePanel.setBackground(Color.white);
        globePanel.add(_animatedGlobeLabel);
        globePanel.add(_staticGlobeLabel);
        
        final JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.white);
        topPanel.setLayout(new BorderLayout());
        topPanel.add(globePanel, BorderLayout.EAST);
        topPanel.add(addressAndNavigationPanel, BorderLayout.WEST);
        add(topPanel, BorderLayout.NORTH);
        
        //Add a action listener.
        final NavigationListener nl = new NavigationListener();
        _backButton.addActionListener(nl);
        _homeButton.addActionListener(nl);
        _address.addActionListener(nl);
        
        //Used to signal the model that the page is 100% loaded.
        _htmlPane.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(final PropertyChangeEvent evt) 
            {
                if (evt.getPropertyName().equals("page"))
                {
                    _model.pageLoadFinished();
                }
            }
        });   

        update(_model, null);
    }

    /**
     * Called by the model. The work is delegated to the AWT thread.
     */
    public void update(final Observable observable, final Object obj)
    {
        SwingUtilities.invokeLater(new UpdateCaller(this));
    }
    
    /**
     * Update the view. Only the AWT thread should call this method since
     * it modifies the GUI components.
     */
    public void updateView()
    {
        synchronized (_model)
        {
            //Check if the browser has changed its current location.
            if (_modelLocationState < _model.getLocationState())
            {
                //Update the address field and start loading.
                _address.setText(_model.getCurrentUrl());
                new PageLoader(_model.getCurrentUrl(), _model, _frame).start();
            }

            //Enable/disable the animated browser icon.
            _animatedGlobeLabel.setVisible(_model.isLoading());
            _staticGlobeLabel.setVisible(!_model.isLoading());

            //Workaround! When not enabling and disabling the button sometimes
            //show the rollover icon, even though the mouse is not over the 
            //button.
            _backButton.setEnabled(false);
            _backButton.setEnabled(true);

            _backButton.setRolloverEnabled(_model.canGoBack());

            final String backToolTip = _model.canGoBack() ?
                "<html>Go back to " + _model.getPreviousUrl() + "</html>" :
                "";
            _backButton.setToolTipText(backToolTip);

            if (!_model.isLoading())
            {
                //Set the title of the frame.
                _frame.setTitle( _getTitle() + " - " + _title);
            }

            _modelLocationState = _model.getLocationState();
        }
    }
    
    /**
     * @return The title of the html page. If no title is found the empty
     *         string is returned.
     */
    private String _getTitle()
    {
        final String html = _htmlPane.getText();
          
        final int titleStart = html.indexOf("<title>") + 7;
        final int titleEnd = html.indexOf("</title>");
        
        if (titleStart == -1 || titleEnd == -1 || titleStart >= titleEnd)
        {
            return "";
        }
        
        return html.substring(titleStart, titleEnd);
    }
        
    /**
     * Simple demo of the browser class. This can also be used as the default
     * startup producedure if no special graphics is required.
     *
     * @param args  The browser can be configured by the args parameter.
     *              args[0] is the homepage of the browser.
     *              args[1] can be set to "debug" and the images will be
     *                      loaded from disk instead of the jar file.
     *              args[2] can be set to "dispose", if so, the frame is
     *              disposed when pressing the X button. Otherwise the
     *              browser will use a System.exit.
     */
    public static void main(final String[] args)
    {
        try
        {
            final String startUrl = (args != null && args.length >= 1) ?
                args[0] : 
                "http://www.bysoft.se/sureshot/";
                
            final boolean loadFromJar = 
                args.length >= 2 ? !args[1].equals("debug") : true;
                
            final boolean exitOnClose = 
                args.length >= 3 ? !args[2].equals("dispose") : true;

            final String[] imageNames = new String[MAX_IMAGE_INDEX];
            imageNames[BACK_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/back.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\back.gif";
            imageNames[BACK_OVER_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/back_over.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\back_over.gif";
            imageNames[BACK_PRESSED_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/back.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\back.gif";
            imageNames[HOME_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/home.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\home.gif";
            imageNames[HOME_OVER_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/home_over.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\home_over.gif";
            imageNames[HOME_PRESSED_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/home.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\home.gif";
            imageNames[GLOBE_STATIC_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/globe_static.gif" :
                "E:\\products\\jbrowser\\graphics\\jbrowser\\globe_static.gif";
            imageNames[GLOBE_ANIMATED_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/globe_animated.gif" : 
                "E:\\products\\jbrowser\\graphics\\jbrowser\\" + 
                "globe_animated.gif";
            imageNames[ICON_IMAGE_INDEX] = 
                loadFromJar ? "/graphics/jbrowser/icon.gif" : 
                    "E:\\products\\jbrowser\\graphics\\jbrowser\\icon.gif";

            //Create a frame. The mini browser is added to this frame.
            final JFrame frame = new JFrame();
            final MiniBrowser miniBrowser = new MiniBrowser(startUrl, 
                                                            imageNames,
                                                            frame,
                                                            "JBrowser");
            frame.setBackground(Color.white);
            frame.getContentPane().add(miniBrowser);
            if (exitOnClose)
            {
                frame.addWindowListener(new WindowAdapter()
                {
                    public void windowClosing(WindowEvent e) 
                    {
                        System.exit(0);
                    }
                });
            }
            frame.pack();
            GuiHelper.center(frame);
            frame.setVisible(true);
        }
        catch (ImageLoaderException e)
        {
            JOptionPane.showMessageDialog(null, e, "Error",
                                          JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Listens for events on the back/home button and the address
     * text field.
     */
    private class NavigationListener 
        implements ActionListener
    {
        public void actionPerformed(final ActionEvent ae)
        {
            final Object source = ae.getSource();
            if (source == _address)
            {
                _model.gotoPage(_address.getText());
            }
            else if (source == _backButton)
            {
                _model.back();
            }
            else if (source == _homeButton)
            {
                _model.home();
            }
            else
            {
                //Can never happen.
                Assertion.assertion(false);
            }
        }
    }
    
    private final JEditorPane _htmlPane = new JEditorPane();
    private final JTextField _address = new JTextField(40);;
    
    private final JButton _backButton = new JButton();
    private final JButton _homeButton = new JButton();
    
    private final JLabel _staticGlobeLabel;
    private final JLabel _animatedGlobeLabel;
    
    private final JFrame _frame;
    private final String _title;
    
    private final BrowserModel _model;
    
    private int _modelLocationState = 0;
    
    /**
     * The browser's model.
     */
    private static class BrowserModel extends Observable
    {
        /**
         * The constructor.
         *
         * @param homepage  The browser's homepage.
         */
        public BrowserModel(final String homepage)
        {
            _homepage = homepage;
            _urlStack.push(_homepage);
            ++_locationState;
        }
        
        /**
         * Move the browser back one html page.
         */
        public synchronized void back()
        {
            if (_urlStack.size() > 1)
            {
                ++_locationState;
                _urlStack.pop();
                _notifyChange();
            }
        }
        
        /**
         * Move the browser to its home page.
         */
        public synchronized void home()
        {
            _urlStack.push(_homepage);
            ++_locationState;
            _notifyChange();
        }
        
        /**
         * Move the browser to the specified url.
         *
         * @param url  The destination url.
         */
        public synchronized void gotoPage(final String url)
        {
            _urlStack.push(url);
            ++_locationState;
            _notifyChange();
        }
        
        /**
         * @return The current url of the browser.
         */
        public synchronized String getCurrentUrl()
        {
            return (String) _urlStack.peek();
        }
        
        /**
         * @return The previous url the browser visited.
         */
        public synchronized String getPreviousUrl()
        {
            return (String) _urlStack.elementAt(_urlStack.size() - 2);
        }
        
        /**
         * @return The location state. The location state begins at 1
         *         and is increased by 1 everytime it moves forward, backward
         *         or to its home page.
         */
        public synchronized int getLocationState()
        {
            return _locationState;
        }
        
        /**
         * @return true if model can move a web page back, else false.
         */
        public synchronized boolean canGoBack()
        {
            return _urlStack.size() > 1;
        }
        
        /**
         * Called to set the model in the loading state.
         */
        public synchronized void newPageLoading()
        {
            _isLoading = true;
            _notifyChange();
        }
        
        /**
         * Called to set the model in the non-loading state.
         */
        public synchronized void pageLoadFinished()
        {
            _isLoading = false;
            _notifyChange();
        }
        
        /**
         * @return true if the model is loading a new web page, else false.
         */
        public synchronized boolean isLoading()
        {
            return _isLoading;
        }
        
        /**
         * Called to notify all observers.
         */
        private synchronized void _notifyChange()
        {
            setChanged();
            notifyObservers();
        }
        
        private final Stack _urlStack = new Stack();
        private final String _homepage;
        
        private int _locationState = 0;
        private boolean _isLoading = false;
    }
}
