/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.gui.util;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 * Class with static utility methods.
 *
 * @author Roger Karlsson
 * @since  February 28, 2002
 */
public class GuiHelper 
{
    /**
     * Centers a frame in the middle of the screen.
     *
     * @param frame  The frame that is centered.
     */
    public static void center(final JFrame frame)
    {
        final Dimension frameSize = frame.getPreferredSize();
        final int frameHeight = (int) frameSize.getHeight();
        final int frameWidth = (int) frameSize.getWidth();
        final Dimension screenSize = 
            Toolkit.getDefaultToolkit().getScreenSize();
        final int x = (screenSize.width  - frameWidth)  / 2;
        final int y = (screenSize.height - frameHeight) / 2;
        frame.setBounds(x, y, frameWidth, frameHeight);
    }
    
    /**
     * Centers the dialog in the middle of the screen.
     *
     * @param dialog  The dialog that is centered.
     */
    public static void center(final JDialog dialog)
    {
        final Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        final int w = dialog.getSize().width;
        final int h = dialog.getSize().height;
        dialog.setLocation(screen.width/2 - w/2,
                           screen.height/2 - h/2);
    }
}
