/*
 * Copyright (C) Sureshot 2002
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Review history:
 *
 */

package se.bysoft.sureshot.gui.util;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;

import se.bysoft.sureshot.debug.Assertion;
import se.bysoft.sureshot.gui.util.GuiHelper;

/**
 * A dialog with an input field.
 *
 * @author Roger Karlsson
 * @since  March 27, 2002
 */
public class TextFieldDialog extends JDialog
{
    /**
     * Enum for what action made the dialog return.
     */
    public static class Action 
    {
        public static final Action CANCEL = new Action();
        public static final Action OK     = new Action();
        protected Action() {}
    }

    /**
     * Create an dialog with a text field.
     */
    public TextFieldDialog(final JFrame owner, 
                           final String defaultText,
                           final String toolTip,
                           final String title,
                           final String message,
                           final int textFieldSize)                               
    {
        super(owner, true);
        
         _textField = new JTextField(textFieldSize);

        setTitle(title);
        
        final JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1,2));
        buttonPanel.add(_okButton);
        buttonPanel.add(_cancelButton);

        final JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(_textField, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        final ButtonListener bl = new ButtonListener();
        _okButton.addActionListener(bl);
        _cancelButton.addActionListener(bl);
        
        final KeyListener kl = new KeyListener();
        _textField.addKeyListener(kl);
        _textField.setText(defaultText);
        _textField.setToolTipText(toolTip);
        
        final Object[] options = {panel};
        final JOptionPane optionPane = new JOptionPane(
            message,
            JOptionPane.QUESTION_MESSAGE,
            JOptionPane.YES_NO_OPTION,
            null,
            options,
            options[0]);
                                
        setContentPane(optionPane);
        pack();
        
        GuiHelper.center(this);
    }
 
    public Action getReturnAction()
    {
        return _action;
    }
    
    public String getTextFieldString()
    {
        return _textField.getText();
    }
    
    /**
     * Listen for events from the ok and cancel button.
     */
    public class ButtonListener implements ActionListener
    {   
        public void actionPerformed(java.awt.event.ActionEvent ev) 
        {
            final Object o = ev.getSource();
            if (o == _okButton)
            {
                _action = Action.OK;
                setVisible(false);
            }
            else if (o == _cancelButton)
            {
                _action = Action.CANCEL;
                setVisible(false);
            }
            else
            {
                Assertion.assertion(false);
            }
        }
    }
    
    /**
     * Listen for key events in the email address text field.
     */
    public class KeyListener extends KeyAdapter
    {            
         public void keyReleased(final KeyEvent e)
         {             
             if (e != null && e.getKeyCode() == KeyEvent.VK_ENTER)
             {
                 _okButton.doClick();
             } 
         } 
    }
    
    /**
     * For unittesting.
     */
    final JButton getOkButton()
    {
        return _okButton;
    }
    
    /**
     * For unittesting.
     */
    final JButton getCancelButton()
    {
        return _cancelButton;
    }
    
    private final JButton _okButton = new JButton("Ok");
    private final JButton _cancelButton = new JButton("Cancel");
    private final JTextField _textField;
    
    //The action that made the dialog close.
    private Action _action = Action.CANCEL;
}
