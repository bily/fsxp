package org.lc0277lib.conf;

public interface ConfigChangeListener {

	public void configChange(ConfigChangeEvent e);
}
